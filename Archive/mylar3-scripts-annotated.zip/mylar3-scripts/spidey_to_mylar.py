#!/usr/bin/env python3
# Full annotated version of spidey_to_mylar.py (as discussed above).
