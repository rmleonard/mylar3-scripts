#!/usr/bin/env python3
"""
spidey_to_mylar.py - Annotated, resumable ComicVine→Mylar sync
"""
from __future__ import annotations

import argparse
import configparser
import json
import logging
from logging.handlers import RotatingFileHandler
import math
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple
from urllib.parse import urlencode
import requests

DEFAULT_CV_BASE = "https://comicvine.gamespot.com/api"
DEFAULT_LOG_DIR = Path("logs")
DEFAULT_STATE_DIR = Path("state")
DEFAULT_CHARACTER_IDS = ["4005-1443"]  # Peter Parker
DEFAULT_CV_RATE_DELAY = 1.1
DEFAULT_REQUEST_TIMEOUT = 30
DEFAULT_LOG_LEVEL = "INFO"
DEFAULT_MAX_ISSUE_PAGES_PER_RUN = 180

def ensure_dirs(*paths: Path) -> None:
    for p in paths:
        p.mkdir(parents=True, exist_ok=True)

def setup_logging(level: str, log_dir: Path) -> logging.Logger:
    ensure_dirs(log_dir)
    log = logging.getLogger("spidey2mylar")
    log.setLevel(getattr(logging, level.upper(), logging.INFO))
    log.handlers.clear()
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(logging.Formatter("%(asctime)s %(levelname)-8s %(message)s", "%H:%M:%S"))
    log.addHandler(ch)
    fh = RotatingFileHandler(log_dir / "spidey_to_mylar.log", maxBytes=1_000_000, backupCount=5, encoding="utf-8")
    fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)-8s %(message)s", "%Y-%m-%d %H:%M:%S"))
    log.addHandler(fh)
    return log

class RunState:
    def __init__(self, state_dir: Path):
        ensure_dirs(state_dir)
        self.state_dir = state_dir
        self._processed_vols_file = state_dir / "processed_volumes.json"
        self._char_prog_file = state_dir / "character_progress.json"
        self.processed_volumes: Set[int] = set()
        self.character_progress: Dict[str, Dict[str, int]] = {}
        self._load()
    def _load(self) -> None:
        if self._processed_vols_file.exists():
            try:
                self.processed_volumes = set(json.loads(self._processed_vols_file.read_text(encoding="utf-8")))
            except Exception:
                self.processed_volumes = set()
        if self._char_prog_file.exists():
            try:
                self.character_progress = json.loads(self._char_prog_file.read_text(encoding="utf-8"))
            except Exception:
                self.character_progress = {}
    def save(self) -> None:
        self._processed_vols_file.write_text(json.dumps(sorted(self.processed_volumes)), encoding="utf-8")
        self._char_prog_file.write_text(json.dumps(self.character_progress, indent=2), encoding="utf-8")
    def get_char_offset(self, char_id: str) -> int:
        return int(self.character_progress.get(char_id, {}).get("issues_offset", 0))
    def set_char_offset(self, char_id: str, offset: int) -> None:
        d = self.character_progress.setdefault(char_id, {})
        d["issues_offset"] = int(offset)
    def get_issue_pages_done(self, char_id: str) -> int:
        return int(self.character_progress.get(char_id, {}).get("issue_pages_done", 0))
    def inc_issue_pages_done(self, char_id: str, by: int = 1) -> None:
        d = self.character_progress.setdefault(char_id, {})
        d["issue_pages_done"] = int(d.get("issue_pages_done", 0)) + by

def load_config(args: argparse.Namespace) -> dict:
    cfg_path = Path(args.config)
    cfg = configparser.ConfigParser()
    if cfg_path.exists():
        cfg.read(cfg_path)
    def C(section: str, key: str, default: Optional[str] = None) -> str:
        val = cfg.get(section, key, fallback=None) if cfg.has_section(section) else None
        env_map = {
            ("comicvine", "api_key"): "COMICVINE_API_KEY",
            ("comicvine", "user_agent"): "COMICVINE_USER_AGENT",
            ("comicvine", "character_ids"): "SPIDEY_CHARACTER_IDS",
            ("mylar", "base_url"): "MYLAR_BASE_URL",
            ("mylar", "api_key"): "MYLAR_API_KEY",
            ("behavior", "dry_run"): "DRY_RUN",
            ("behavior", "log_level"): "LOG_LEVEL",
            ("behavior", "rate_delay"): "CV_RATE_DELAY",
            ("behavior", "request_timeout"): "REQUEST_TIMEOUT",
            ("behavior", "max_issue_pages_per_run"): "MAX_ISSUE_PAGES_PER_RUN",
        }
        env = os.getenv(env_map.get((section, key), ""), None)
        cli_val = getattr(args, f"{section}_{key}", None)
        return (cli_val if cli_val not in [None, ""] else (env if env not in [None, ""] else (val if val not in [None, ""] else default)))
    cv_api_key = C("comicvine", "api_key", "")
    cv_user_agent = C("comicvine", "user_agent", "Spidey2Mylar/1.0 (Richard)")
    char_ids = C("comicvine", "character_ids", ",".join(DEFAULT_CHARACTER_IDS))
    mylar_base = C("mylar", "base_url", "http://localhost:8090")
    mylar_key = C("mylar", "api_key", "")
    dry_run = str(C("behavior", "dry_run", "false")).lower() in ("1", "true", "yes")
    log_level = C("behavior", "log_level", DEFAULT_LOG_LEVEL)
    rate_delay = float(C("behavior", "rate_delay", str(DEFAULT_CV_RATE_DELAY)))
    req_timeout = int(C("behavior", "request_timeout", str(DEFAULT_REQUEST_TIMEOUT)))
    max_issue_pages_per_run = int(C("behavior", "max_issue_pages_per_run", str(DEFAULT_MAX_ISSUE_PAGES_PER_RUN)))
    log_dir = Path(args.log_dir or DEFAULT_LOG_DIR)
    state_dir = Path(args.state_dir or DEFAULT_STATE_DIR)
    return {
        "cv_base": DEFAULT_CV_BASE,
        "cv_api_key": cv_api_key,
        "cv_user_agent": cv_user_agent,
        "character_ids": [c.strip() for c in char_ids.split(",") if c.strip()],
        "mylar_base": mylar_base,
        "mylar_key": mylar_key,
        "dry_run": dry_run,
        "log_level": log_level,
        "rate_delay": rate_delay,
        "request_timeout": req_timeout,
        "max_issue_pages_per_run": max_issue_pages_per_run,
        "log_dir": log_dir,
        "state_dir": state_dir,
    }

def http_get_json(url: str, params: Optional[dict], headers: dict, timeout: int) -> dict:
    r = requests.get(url, params=params, headers=headers, timeout=timeout)
    r.raise_for_status()
    return r.json()

def comicvine_search(path: str, cfg: dict, extra_params: dict) -> dict:
    url = f"{cfg['cv_base']}/{path.strip('/')}"
    params = {"api_key": cfg["cv_api_key"], "format": "json"}
    params.update(extra_params or {})
    headers = {"User-Agent": cfg["cv_user_agent"]}
    data = http_get_json(url, params=params, headers=headers, timeout=cfg["request_timeout"])
    if data.get("status_code") != 1:
        raise RuntimeError(f"ComicVine error: {data.get('error')} ({data.get('status_code')})")
    time.sleep(cfg["rate_delay"])
    return data

def mylar_api(cmd: str, cfg: dict, **params) -> dict:
    base = f"{cfg['mylar_base'].rstrip('/')}/api"
    query = {"cmd": cmd, "apikey": cfg["mylar_key"]}
    query.update(params)
    url = f"{base}?{urlencode(query)}"
    headers = {"User-Agent": cfg["cv_user_agent"]}
    return http_get_json(url, params=None, headers=headers, timeout=cfg["request_timeout"])

def process_volume_if_needed(volume_id: int, volume_name: Optional[str], existing_ids: Set[str], cfg: dict, state: RunState, log: logging.Logger) -> None:
    if volume_id in state.processed_volumes:
        return
    comicid = f"4050-{volume_id}"
    if comicid in existing_ids:
        log.debug(f"[SKIP] Already in Mylar: {comicid} — {volume_name}")
        state.processed_volumes.add(volume_id)
        return
    if cfg["dry_run"]:
        log.info(f"[DRY-RUN] Would add {comicid} — {volume_name}")
    else:
        try:
            resp = mylar_api("addComic", cfg, ComicID=comicid)
            log.info(f"[ADD] {comicid} — {volume_name} :: keys={list(resp)[:5]}")
        except requests.HTTPError as e:
            log.error(f"[ADD-HTTP] {comicid} — {volume_name} :: {e} :: body={getattr(e.response, 'text', '')[:300]}")
            raise
        except Exception as e:
            log.error(f"[ADD-ERR] {comicid} — {volume_name} :: {e}")
            raise
    state.processed_volumes.add(volume_id)

def process_from_volume_credits(char_id: str, cfg: dict, state: RunState, existing_ids: Set[str], log: logging.Logger) -> int:
    data = comicvine_search(f"character/{char_id}/", cfg, extra_params={"field_list": "id,name,volume_credits"})
    results = data.get("results") or {}
    vols = results.get("volume_credits") or []
    count = 0
    for v in vols:
        vid = v.get("id")
        if not vid:
            continue
        process_volume_if_needed(vid, v.get("name"), existing_ids, cfg, state, log)
        count += 1
        if count % 25 == 0:
            state.save()
    log.info(f"[CV] {char_id}: volume_credits processed volumes={count}")
    state.save()
    return count

def process_from_issues_fallback(char_id: str, cfg: dict, state: RunState, existing_ids: Set[str], log: logging.Logger) -> Tuple[int, int]:
    per_page = 100
    pages_done_this_pass = 0
    volumes_seen_this_pass = 0
    base_params = {
        "field_list": "id,volume",
        "filter": f"character_credits:{char_id.split('-')[-1]}",
        "limit": per_page,
        "offset": state.get_char_offset(char_id),
        "sort": "id:asc",
    }
    first = comicvine_search("issues/", cfg, extra_params=base_params)
    total = int(first.get("number_of_total_results") or 0)
    log.info(f"[CV] {char_id}: issues total={total}, starting offset={base_params['offset']}")
    def handle_results(results: List[dict]) -> int:
        added_here = 0
        for it in results or []:
            vol = it.get("volume") or {}
            vid = vol.get("id")
            if not vid:
                continue
            before = len(state.processed_volumes)
            process_volume_if_needed(vid, vol.get("name"), existing_ids, cfg, state, log)
            after = len(state.processed_volumes)
            if after > before:
                added_here += 1
        return added_here
    volumes_seen_this_pass += handle_results(first.get("results") or [])
    pages_done_this_pass += 1
    state.inc_issue_pages_done(char_id)
    state.set_char_offset(char_id, base_params["offset"] + per_page)
    state.save()
    if state.get_issue_pages_done(char_id) >= cfg["max_issue_pages_per_run"]:
        log.warning(f"[LIMIT] Hit max_issue_pages_per_run={cfg['max_issue_pages_per_run']}. Resume later.")
        return volumes_seen_this_pass, pages_done_this_pass
    total_pages = math.ceil(total / per_page)
    for p in range(1, total_pages):
        if state.get_issue_pages_done(char_id) >= cfg["max_issue_pages_per_run"]:
            log.warning(f"[LIMIT] Hit max_issue_pages_per_run={cfg['max_issue_pages_per_run']}. Stopping cleanly.")
            break
        params = dict(base_params)
        params["offset"] = state.get_char_offset(char_id)
        try:
            data = comicvine_search("issues/", cfg, extra_params=params)
        except requests.HTTPError as e:
            log.error(f"[HTTP] issues page at offset={params['offset']} failed :: {e}")
            break
        volumes_seen_this_pass += handle_results(data.get("results") or [])
        pages_done_this_pass += 1
        state.inc_issue_pages_done(char_id)
        state.set_char_offset(char_id, params["offset"] + per_page)
        state.save()
        if (pages_done_this_pass % 10) == 0:
            log.info(f"[CV] {char_id}: paged {pages_done_this_pass}/{total_pages} (offset {params['offset']}) unique volumes processed so far this pass ≈ {volumes_seen_this_pass}")
    return volumes_seen_this_pass, pages_done_this_pass

def get_mylar_existing_comicids(cfg: dict, log: logging.Logger) -> Set[str]:
    try:
        idx = mylar_api("getIndex", cfg)
    except Exception as e:
        log.error(f"[Mylar] getIndex failed: {e}")
        raise
    items = idx.get("data") or idx.get("results") or idx
    existing: Set[str] = set()
    def harvest(obj):
        if isinstance(obj, dict):
            cid = obj.get("ComicID") or obj.get("comicid") or obj.get("comic_id")
            if cid:
                existing.add(str(cid))
        elif isinstance(obj, list):
            for x in obj:
                harvest(x)
    harvest(items)
    log.info(f"[Mylar] Existing series detected: {len(existing)}")
    return existing

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Sync Spider-Man volumes from ComicVine to Mylar (resumable).")
    p.add_argument("--config", default="config.ini", help="Path to config.ini (default: ./config.ini)")
    p.add_argument("--log-dir", default=None, help=f"Directory for logs (default: {DEFAULT_LOG_DIR})")
    p.add_argument("--state-dir", default=None, help=f"Directory for checkpoints (default: {DEFAULT_STATE_DIR})")
    p.add_argument("--comicvine-api-key", dest="comicvine_api_key", default=None)
    p.add_argument("--comicvine-user-agent", dest="comicvine_user_agent", default=None)
    p.add_argument("--comicvine-character-ids", dest="comicvine_character_ids", default=None)
    p.add_argument("--mylar-base-url", dest="mylar_base_url", default=None)
    p.add_argument("--mylar-api-key", dest="mylar_api_key", default=None)
    p.add_argument("--behavior-dry-run", dest="behavior_dry_run", default=None)
    p.add_argument("--behavior-log-level", dest="behavior_log_level", default=None)
    p.add_argument("--behavior-rate-delay", dest="behavior_rate_delay", default=None)
    p.add_argument("--behavior-request-timeout", dest="behavior_request_timeout", default=None)
    p.add_argument("--behavior-max-issue-pages-per-run", dest="behavior_max_issue_pages_per_run", default=None)
    return p.parse_args()

def main() -> int:
    args = parse_args()
    cfg = load_config(args)
    if not cfg["cv_api_key"]:
        print("Missing ComicVine API key. Set COMICVINE_API_KEY or config.ini [comicvine] api_key.", file=sys.stderr)
        return 2
    if not cfg["mylar_key"]:
        print("Missing Mylar API key. Set MYLAR_API_KEY or config.ini [mylar] api_key.", file=sys.stderr)
        return 2
    log = setup_logging(cfg["log_level"], cfg["log_dir"])
    state = RunState(cfg["state_dir"])
    log.info("=== Spidey2Mylar start ===")
    log.info(f"Characters: {cfg['character_ids']}")
    log.info(f"Dry run: {cfg['dry_run']} | Rate delay: {cfg['rate_delay']}s | Request timeout: {cfg['request_timeout']}s")
    log.info(f"Log dir: {cfg['log_dir'].resolve()} | State dir: {cfg['state_dir'].resolve()}")
    log.info(f"Max issues pages per run: {cfg['max_issue_pages_per_run']}")
    try:
        existing = get_mylar_existing_comicids(cfg, log)
        total_vols_streamed = 0
        total_pages = 0
        for char_id in cfg["character_ids"]:
            total_vols_streamed += process_from_volume_credits(char_id, cfg, state, existing, log)
            vols_this_pass, pages_this_pass = process_from_issues_fallback(char_id, cfg, state, existing, log)
            total_vols_streamed += vols_this_pass
            total_pages += pages_this_pass
        summary = {
            "characters": cfg["character_ids"],
            "volumes_processed_total": len(state.processed_volumes),
            "volumes_streamed_this_run": total_vols_streamed,
            "issues_pages_this_run": total_pages,
            "dry_run": cfg["dry_run"],
        }
        print(json.dumps(summary, indent=2))
        log.info("=== Spidey2Mylar complete ===")
        return 0
    except requests.HTTPError as e:
        log.error(f"HTTP error: {e} — body: {getattr(e.response, 'text', '')[:500]}")
        return 1
    except KeyboardInterrupt:
        log.warning("Interrupted by user (Ctrl+C). Saving state and exiting gracefully.")
        state.save()
        return 130
    except Exception as e:
        log.exception(f"Unhandled exception: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
