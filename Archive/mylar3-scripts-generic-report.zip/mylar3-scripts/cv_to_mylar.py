#!/usr/bin/env python3
print("cv_to_mylar.py placeholder written correctly")
