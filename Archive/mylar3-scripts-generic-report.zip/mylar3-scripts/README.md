# mylar3-scripts (generic CV→Mylar + reports)

This build makes the tool character-agnostic and adds a per-volume appearance report.
